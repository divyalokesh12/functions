﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FunctionApp1.Email
{
	public class EmailConfig

	{
        private string v1;
        private int v2;

        public string Host { get; set; }
		public int Port { get; set; }
		public string Sender { get; set; }
		public string Password { get; set; }

		public EmailConfig(string host, int port, string sender, string password)
		{
			if (host == null)
			{
				throw new ArgumentNullException(nameof(host));
			}

			if (sender == null)
			{
				throw new ArgumentNullException(nameof(sender));
			}

			if (password == null)
			{
				throw new ArgumentNullException(nameof(password));
			}

			Host = host;
			Port = port;
			Sender = sender;
			Password = password;
		}

        public EmailConfig(string v1, int v2)
        {
            this.v1 = v1;
            this.v2 = v2;
        }
    }
}
