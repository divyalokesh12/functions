﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AzureQueueLibrary.Infrastructure
{
  public  class RouteNames
    {
        public const string EmailBox = "email-box";

    }
}
