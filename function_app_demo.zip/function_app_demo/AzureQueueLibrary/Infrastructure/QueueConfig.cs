﻿using Microsoft.WindowsAzure.Storage.Blob.Protocol;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace AzureQueueLibrary.Infrastructure
{
    public class QueueConfig
    {
        public string QueueConnectionString { get; set; }

        public QueueConfig()
        {
        }


        public QueueConfig(string queueConnectionString)
        {
            QueueConnectionString = queueConnectionString;
        }

    }

}
