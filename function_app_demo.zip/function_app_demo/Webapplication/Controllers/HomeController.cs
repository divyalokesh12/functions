﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using AzureQueueLibrary.Messages;
using AzureQueueLibrary.QueueConnection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Webapplication.Models;

namespace Webapplication.Controllers
{
    public class HomeController : Controller
    {
      
        private readonly IQueueCommunicator _queueCommunicator;

       
        public HomeController(IQueueCommunicator queueCommunicator)
        {
            _queueCommunicator = queueCommunicator;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult ContactUs()
        {
            ViewBag.Message = "";
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ContactUs(string contactName, string emailAddress)
        {
            //send thank you email to contact
            var thankYouEmail = new SendEmailCommand()
            {
                To = emailAddress,
                Subject = "Thank You for reaching out",
                Body = "we will contact you surely",
            };
            await _queueCommunicator.SendAsync(thankYouEmail);

            //send new contact email to admin
            var adminEmail = new SendEmailCommand()
            {
                To = "admin@test.com",
                Subject = "new contact",
                Body = $"{contactName} has reached out via contact form. Please respond back at {emailAddress}",
            };
            await _queueCommunicator.SendAsync(adminEmail);

            ViewBag.Message = "thank you we recieved your message";
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
